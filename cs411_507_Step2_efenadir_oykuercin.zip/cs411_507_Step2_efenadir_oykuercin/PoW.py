#created by Efe Nadir, Oyku Ercin

import math
import string
import sympy
import os.path
import sys
import random
import pyprimes
import warnings
import string
from Crypto.Hash import SHA3_256
from Crypto.Hash import SHAKE128

#CheckPow Function
def CheckPow(p, q, g, PoWLen, TxCnt, filename): 
    hashTree = [] 
    file = open(filename, "r")
    tx_block = file.readlines()
    last= tx_block[len(tx_block) -1]
    nonce = last[7:46]
    file.close()
    if len(tx_block)%7 != 1:
        print("Incorrect file format")
    else:
        tx_block_count = len(tx_block)//7
        for i in range(0, tx_block_count):
            transaction = tx_block[i*7:(i+1)*7]
            transaction = "".join(transaction)
            transaction= transaction.encode('UTF-8')
            h = SHA3_256.new(transaction).digest()
            hashTree.append(h)
    t = TxCnt
    j = 0
    while (t>1):
        for i in range(j,j+t,2):
            a = hashTree[i]+hashTree[i+1]
            h = SHA3_256.new(a).digest()
            hashTree.append(h)
        j += t
        t = t>>1

    root_hash = hashTree[2*TxCnt-2]
    digest = root_hash+ (str(nonce)+'\n').encode('UTF-8')
    pow_num = SHA3_256.new(digest).hexdigest()
    return pow_num

#PoW function
def PoW(PoWLen, p, q, g, TxCnt, filename):
    hashTree = [] 
    file = open(filename, "r")
    tx_block = file.readlines()
    file.close()
    if len(tx_block)%7 != 0:
        print("Incorrect file format")
    else:
        tx_block_count = len(tx_block)//7
        for i in range(0, tx_block_count):
            transaction = tx_block[i*7:(i+1)*7]
            transaction = "".join(transaction)
            transaction= transaction.encode('UTF-8')
            h = SHA3_256.new(transaction).digest()
            hashTree.append(h)
    t = TxCnt
    j = 0
    while (t>1):
        for i in range(j,j+t,2):
            a = hashTree[i]+hashTree[i+1]
            h = SHA3_256.new(a).digest()
            hashTree.append(h)
        j += t
        t = t>>1
    root_hash2 = hashTree[2*TxCnt-2]            
    h = ""
    while (h[:PoWLen] != PoWLen*"0"):
        nonce = random.getrandbits(128)
        digest = root_hash2+ (str(nonce)+'\n').encode('UTF-8')
        h = SHA3_256.new()
        h.update(digest) #hashed 
        h = h.hexdigest()          
    transactions = []
    file = open("transactions.txt", "r")
    tx_block = file.readlines()
    file.close()
    if len(tx_block)%7 != 0:
        print("Incorrect file format")
    else:
        tx_block_count = len(tx_block)//7
        for i in range(0, tx_block_count):
            transaction = tx_block[i*7:(i+1)*7]
            transaction = "".join(transaction)
            transactions.append(transaction)   
    trans = "".join(transactions)
    nonce = "Nonce: " + str(nonce)
    block = trans + nonce
    return block

    
