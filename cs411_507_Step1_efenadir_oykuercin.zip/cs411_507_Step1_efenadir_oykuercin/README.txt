We did this project at Anaconda, Jupyter. In order to did this, at the Phasel_Test.py module, we used 2 additional statements in order to get the other functions and parameters at DS.py and Tx.py

We wrote additional these:

from DS import *
from Tx import *

Please take consider. 

Thank you.
