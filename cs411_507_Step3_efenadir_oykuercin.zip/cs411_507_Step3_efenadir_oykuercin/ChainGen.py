#created by  Efe Nadir, Oyku Ercin
# coding: utf-8


import random
import math
import pyprimes, sys
import hashlib
from ecpy.curves import Curve,Point
from Crypto.Hash import SHA3_256

TxLen = 9

def CheckBlock(TxCnt, Block):
    hashTree = []
    for i in range(0,TxCnt):
        transaction = "".join(Block[i*TxLen:(i+1)*TxLen])
        hashTree.append(SHA3_256.new(transaction.encode('UTF-8')).digest())
    t = TxCnt
    j = 0
    while(t>1):
        for i in range(j,j+t,2):
            hashTree.append(SHA3_256.new(hashTree[i]+hashTree[i+1]).digest())
        j += t
        t = t>>1

    H_r = hashTree[2*TxCnt-2] 
        
    PrevPoW = Block[-2][14:-1]
    PrevPoW = PrevPoW.encode('UTF-8')
    
    nonce = int(Block[-1][7:-1])
    digest = H_r + PrevPoW + nonce.to_bytes((nonce.bit_length()+7)//8, byteorder = 'big')
    
    PoW = SHA3_256.new(digest).hexdigest()
    return PoW, Block[-2][14:-1] 


def ReturnHR(TxCnt, Block):
    hashTree = []
    for i in range(0,TxCnt):
        transaction = "".join(Block[i*TxLen:(i+1)*TxLen])
        hashTree.append(SHA3_256.new(transaction.encode('UTF-8')).digest())
    t = TxCnt
    j = 0
    while(t>1):
        for i in range(j,j+t,2):
            
            hashTree.append(SHA3_256.new(hashTree[i]+hashTree[i+1]).digest())
        j += t
        t = t>>1

    H_r = hashTree[2*TxCnt-2]
    return H_r

def AddBlock2Chain(PoWLen, TxCount, NewBlock, PrevBlock):
    if PrevBlock == "":
        PrevPoW = '00000000000000000000' 
    else:
        PrevPoW, prepow = CheckBlock(TxCount, PrevBlock)
     
    f = open("tmp.txt", "r")
    block = f.readlines()
    block = "".join(block)
    f.close()
    
    H_r = ReturnHR(TxCount, NewBlock)  
    nonce = random.getrandbits(128)
    digest = H_r +  bytes(PrevPoW ,'UTF-8') + nonce.to_bytes((nonce.bit_length()+7)//8, byteorder = 'big')
    hash_result = SHA3_256.new(digest).hexdigest()
    while ((hash_result[:PoWLen]) != "0"*PoWLen):
        nonce = random.getrandbits(128)
        digest = H_r +  bytes(PrevPoW ,'UTF-8') + nonce.to_bytes((nonce.bit_length()+7)//8, byteorder = 'big')
        hash_result = SHA3_256.new(digest).hexdigest()

    block = block + "Previous PoW: " + str(PrevPoW) + "\n"
    block = block + "Nonce: " + str(nonce)  + " "
    return str(block), PrevPoW     


