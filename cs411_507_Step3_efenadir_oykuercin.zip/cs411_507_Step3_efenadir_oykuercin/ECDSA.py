#created by Efe Nadir, Oyku Ercin
# coding: utf-8

import math
import string
import sympy
import os.path
import sys
import random
import pyprimes
import warnings
import string
from Crypto.Hash import SHA3_256
from Crypto.Hash import SHAKE128

#Helper Functions
def egcd(a, b):
    x,y, u,v = 0,1, 1,0
    while a != 0:
        q, r = b//a, b%a
        m, n = x-u*q, y-v*q
        b,a, x,y, u,v = a,r, u,v, m,n
    gcd = b
    return gcd, x, y

def modinv(a, m):
    if a < 0:
        a = a+m
    gcd, x, y = egcd(a, m)
    if gcd != 1:
        return None  # modular inverse does not exist
    else:
        return x % m



def KeyGen(E): 
    n = E.order 
    P = E.generator  
    
    secret= random.randint(1,n-1) 
    public = secret*P 

    return secret,public


def SignGen(message, E, sA):
    n = E.order #mod
    P = E.generator #point(x,y)

    h = SHA3_256.new(message)  
    h = int.from_bytes(h.digest(), byteorder='big')
   
    k = random.randint(1, n-1) 

    R = k*P #another point by Generator
    r_x = R.x % n 
    s = ((sA*r_x) - (k*h)) % n
    return s, r_x


def SignVer(message, s, r, E, QA):
    n = E.order
    P = E.generator

    h = SHA3_256.new(message)  
    h = int.from_bytes(h.digest(), byteorder='big')

    v = modinv(h, n) % n

    z1 = (s*v) % n #points on curve
    z2 = (r*v) % n #points on curve
    U = ((n-z1)*P)+(z2*QA)
    u = U.x % n
    if u == r:
        return 0
    else: 
        return -1
